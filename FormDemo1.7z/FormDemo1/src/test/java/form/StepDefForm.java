package form;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefForm {
	private PageFactForm pageFormFact = null;
	static WebDriver driver = null;

	@Given("^user is on home page$")
	public void user_is_on_home_page() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ramdasar\\Documents\\chromedriver.exe");
		driver = new ChromeDriver();
		pageFormFact = new PageFactForm(driver);
		driver.get("file:///C:/Users/ramdasar/Desktop/FormDemo.html");
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name(DataTable arg1) throws Exception {
		/*pageFormFact.setMobileno("8143227388");
		Thread.sleep(1000);
		pageFormFact.setEmail("ramya@gmail.com");
		Thread.sleep(1000);
		pageFormFact.setAddress("Eluru");
		Thread.sleep(1000);
		pageFormFact.setButton();*/
		List<String> objList = arg1.asList(String.class);
		String data = null;
		for (String dataTemp : objList) {
			data = dataTemp;
			pageFormFact.getName1().clear();
			pageFormFact.setName1(data);
			Thread.sleep(1000);
			pageFormFact.setButton();

			if (data.matches("^[A-Z]{1}[a-z]{3,10}$")) {
				System.out.println("Matching ");
			} else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				Thread.sleep(1000);
				System.out.println("not matched " + alertMessage);
			}
		}
		
	}

	@Then("^displays alert message$")
	public void displays_alert_message() throws Exception {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		System.out.println("not matched " + alertMessage);
	}
	@When("^user enters invalid (\\d+)$")
	public void user_enters_invalid(Integer arg1) throws Exception {

		pageFormFact.setName1("Ramya");
		Thread.sleep(1000);
		pageFormFact.setMobileno(arg1.toString());
		pageFormFact.setButton();
	}

	@When("^enters invalid mail$")
	public void enters_invalid_mail(DataTable arg1) throws Exception {

		pageFormFact.setName1("Ramya");
		Thread.sleep(1000);
		pageFormFact.setMobileno("8143227388");
		Thread.sleep(1000);
		List<String> objList = arg1.asList(String.class);
		String data = null;
		for (String dataTemp : objList) {
			data = dataTemp;
			pageFormFact.getEmail().clear();
			pageFormFact.setEmail(data);
			Thread.sleep(1000);
			pageFormFact.setButton();

			if (data.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$")) {
				System.out.println("Matching ");
			} else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				Thread.sleep(1000);
				System.out.println("not matched " + alertMessage);
			}
		}
	

	}
	
	@Then("^displays alert messages$")
	public void displays_alert_messages() throws Throwable {
	System.out.println("valid");
	}


	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Exception {

		pageFormFact.setName1("Ramya");
		Thread.sleep(1000);
		pageFormFact.setMobileno("8143227388");
		Thread.sleep(1000);
		pageFormFact.setEmail("ramya@gmail.com");
		Thread.sleep(1000);
		pageFormFact.setAddress("");
		Thread.sleep(1000);
		pageFormFact.setButton();

	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Exception {
		pageFormFact.setName1("Ramya");
		Thread.sleep(1000);
		pageFormFact.setMobileno("8143227388");
		Thread.sleep(1000);
		pageFormFact.setEmail("ramya@gmail.com");
		Thread.sleep(1000);
		pageFormFact.setAddress("Eluru");
		Thread.sleep(1000);
		pageFormFact.setButton();
		
	}

	@Then("^navigates to success page$")
	public void navigates_to_success_page() throws Exception {
		
		System.out.println("Registered successfully");
	
	}
	
	
	@After
	public void destroy() {
		driver.close();
	}

}
