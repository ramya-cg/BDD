package form;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactForm {

	WebDriver wd;

	public PageFactForm(WebDriver driver) {
		this.wd = driver;
		PageFactory.initElements(wd, this);
	}

	public PageFactForm() {

	}

	@FindBy(name = "name")
	@CacheLookup
	WebElement name1;

	@FindBy(name = "mobile")
	@CacheLookup
	WebElement mobileno;

	@FindBy(name = "mail")
	@CacheLookup
	WebElement email;

	@FindBy(name = "male")
	@CacheLookup
	WebElement male;

	@FindBy(name = "female")
	@CacheLookup
	WebElement female;

	/*
	 * @FindBy(how=How.NAME, using = "[type='radio'][value='Female']")
	 * 
	 * @CacheLookup WebElement gender;
	 */

	@FindBy(name="address")
	@CacheLookup
	WebElement address;

	@FindBy(xpath = "//*[@value='Submit']")
	@CacheLookup
	WebElement button;

	// Setters and Getters

	public WebElement getName1() {
		return name1;
	}

	public void setName1(String fname) {
		name1.sendKeys(fname);
	}

	public WebElement getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno1) {
		mobileno.sendKeys(mobileno1);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String emailId) {
		email.sendKeys(emailId);
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale(WebElement male) {
		male.click();
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale(WebElement female) {
		female.click();
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address1) {
		address.sendKeys(address1);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

}
